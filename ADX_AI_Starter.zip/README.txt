ADX AI starter (phone-friendly PWA)

This is a starter dashboard, not a full phone-control agent.
It currently creates a simple listing draft from details you enter.

To install:
1. Upload these files to a GitHub repository.
2. In the repository, open Settings > Pages.
3. Set deployment source to Deploy from a branch, choose main and / (root), then Save.
4. Wait for the Pages URL. Open it in Chrome on Android.
5. Chrome menu (⋮) > Add to Home screen / Install app.

Next development stages: connect a secure AI backend, photo upload/JPG conversion,
image generation, then carefully permitted assisted form filling. Never put API keys
or marketplace passwords in browser JavaScript.
